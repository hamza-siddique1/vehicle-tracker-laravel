<div class="col-12 col-lg-6 d-flex">
    <div class="card flex-fill">
        <div class="card-header">
            <h5 class="card-title mb-0">Last 30 Updated Vehicles</h5>
        </div>
        <table class="vehicles-table table table-sm table-striped my-0">
            <thead>
                <tr>
                    <th>Year Make Model</th>
                    <th>VIN</th>
                    <th>Days in Yard</th>
                </tr>
            </thead>
            <tbody class="text-end">
                <?php if(count($last_30_updated)): ?>
                    <?php $__currentLoopData = $last_30_updated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($vehicle->id); ?>">
                            <td><a href="#" data-toggle="modal"
                                    data-target="#modal-vehicle-detail"><?php echo e($vehicle->description); ?></a></td>
                            <td>
                                <?php if($vehicle->auction_lot): ?>
                                    <a href="https://seller.copart.com/lotdisplay/<?php echo e($vehicle->auction_lot); ?>"
                                        target="_blank"><?php echo e($vehicle->vin); ?></a>
                                <?php else: ?>
                                    <?php echo e($vehicle->vin); ?>

                                <?php endif; ?>
                            </td>
                            <td data-toggle="tooltip" data-placement="top"
                                title="<?php echo e($vehicle->updated_at); ?>">
                                <?php echo e($vehicle->human_readable_format); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">No vehicles found</td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td colspan="3">
                        <a href="<?php echo e(route('dashboard.index', ['type' => 'updated'])); ?>" class="btn btn-primary">View All</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/pages/dashboard/_inc/last_30_updated_vehicles.blade.php ENDPATH**/ ?>