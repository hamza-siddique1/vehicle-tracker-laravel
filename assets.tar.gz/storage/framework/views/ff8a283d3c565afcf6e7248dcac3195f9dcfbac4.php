<?php $__env->startSection('alert'); ?>
    <script>
        window.notyf.open({
            'type': '<?php echo e($type); ?>',
            'message': '<?php echo e($slot); ?>',
            'duration': 12000,
            'ripple': true,
            'dismissible': true
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/components/alert.blade.php ENDPATH**/ ?>