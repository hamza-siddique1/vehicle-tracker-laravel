<div class="row">
    <div class="col-12 col-lg-6 d-flex">
        <div class="card flex-fill">
            <div class="card-header">
                <h3 class="mb-2"> Most Days at Auction</h3>
            </div>
            <table class="vehicles-table table table-sm table-striped table-hover my-0">
                <thead>
                    <tr>
                        <th>Year Make Model</th>
                        <th>VIN</th>
                        <th>Days in Yard</th>
                    </tr>
                </thead>
                <tbody class="text-end">
                    <?php if(count($vehicles_with_days_in_yard)): ?>
                        <?php $__currentLoopData = $vehicles_with_days_in_yard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($vehicle->id); ?>">
                                <td><a href="#" data-toggle="modal"
                                        data-target="#modal-vehicle-detail"><?php echo e($vehicle->description); ?></a></td>
                                <td><a href="https://seller.copart.com/lotdisplay/<?php echo e($vehicle->auction_lot); ?>"
                                        target="_blank"><?php echo e($vehicle->vin); ?></a></td>
                                <td><a href="#" data-toggle="modal"
                                        data-target="#modal-vehicle-detail"><?php echo e($vehicle->meta_value); ?></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No vehicles found</td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="3">
                            <a href="<?php echo e(route('dashboard.index', ['type' => 'days_in_yard'])); ?>" class="btn btn-primary">View All</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="col-12 col-lg-6 d-flex">
        <div class="card flex-fill">
            <div class="card-header">
                <h3 class="mb-2">Recently Sold Vehicles</h3>
            </div>
            <table class="vehicles-table table table-sm table-striped table-hover my-0">
                <thead>
                    <tr>
                        <th>Year Make Model</th>
                        <th>VIN</th>
                    </tr>
                </thead>
                <tbody class="text-end">
                    <?php if(count($vehicles_sold)): ?>
                        <?php $__currentLoopData = $vehicles_sold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($vehicle->id); ?>">
                                <td><a href="#" data-toggle="modal"
                                        data-target="#modal-vehicle-detail"><?php echo e($vehicle->description); ?></a></td>
                                        <td>
                                            <?php if($vehicle->auction_lot): ?>
                                                <a href="https://seller.copart.com/lotdisplay/<?php echo e($vehicle->auction_lot); ?>"
                                                    target="_blank"><?php echo e($vehicle->vin); ?></a>
                                            <?php else: ?>
                                                <?php echo e($vehicle->vin); ?>

                                            <?php endif; ?>
                                        </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No vehicles found</td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="3">
                            <a href="<?php echo e(route('dashboard.index', ['type' => 'sold'])); ?>" class="btn btn-primary">View All</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/pages/dashboard/_inc/sold-table.blade.php ENDPATH**/ ?>