<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="modal fade" id="modal-vehicle-detail" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <form class="vehicle-detail-form" id="vehicle-detail-form" method="post" action="#">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Vehicle Details</h5>
                            </div>

                            <div id="vehicle-detail-div"></div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" id="close-modal-btn"
                                        data-dismiss="modal">Close
                                </button>
                                <button type="submit" class="btn btn-primary"
                                        <?php if($role == 'viewer'): ?>
                                            disabled
                                    <?php endif; ?>
                                >Save changes
                                </button>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/pages/vehicle/modal/modal-detail.blade.php ENDPATH**/ ?>