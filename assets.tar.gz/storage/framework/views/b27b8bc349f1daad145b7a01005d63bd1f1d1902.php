<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form>
                    <input type="hidden" class="d-none" name="filter" value="true" hidden>
                    <div class="row">

                        <div class="col-sm">
                            <div class="form-group">
                                <label class="form-label" for="location"> Location </label>
                                <select name="location" id="location"
                                    class="form-control form-select custom-select select2" data-toggle="select2">
                                    <option value="-100"> Select Location</option>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location); ?>"
                                            <?php echo e(request()->location == $location ? 'selected' : ''); ?>><?php echo e($location); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm">
                            <div class="form-group">
                                <label class="form-label" for="status"> Status </label>
                                <select name="status" id="status"
                                    class="form-control form-select custom-select select2" data-toggle="select2">
                                    <option value="-100"> Select Status</option>
                                    <?php $__currentLoopData = \App\Models\Vehicle::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($status != 'SOLD'): ?>
                                            <option value="<?php echo e($status); ?>"
                                                <?php echo e(request()->status == $status ? 'selected' : ''); ?>><?php echo e($status); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-sm">
                            <div class="form-group">
                                <label class="form-label" for="claim_number">Claim Number</label>
                                <input id="claim_number" class="form-control" type="text" name="claim_number"
                                    value="<?php echo e(request()->claim_number); ?>" placeholder="Enter Claim #" />
                            </div>
                        </div>

                        <div class="col-sm">
                            <div class="form-group">
                                <label class="form-label" for="left_location">Left Location</label>
                                <input id="left_location" class="form-control daterange-filter" type="text"
                                    name="left_location" value="<?php echo e(request()->left_location); ?>"
                                    placeholder="<?php echo e(__('Select Date range')); ?>" />
                            </div>
                        </div>

                        <div class="col-sm">
                            <div class="form-group">
                                <label class="form-label" for="date_paid">Date Paid</label>
                                <input id="date_paid" class="form-control daterange-filter" type="text"
                                    name="date_paid" value="<?php echo e(request()->date_paid); ?>"
                                    placeholder="<?php echo e(__('Select Date range')); ?>" />
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm mt-4">
                            <button type="button"
                                class="btn btn-sm btn-primary apply-dt-filters mt-2"><?php echo e(__('Apply')); ?></button>
                            <button type="button"
                                class="btn btn-sm btn-secondary clear-dt-filters mt-2"><?php echo e(__('Clear')); ?></button>


                        </div>
                    </div>


                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/pages/vehicle/filters/filters.blade.php ENDPATH**/ ?>