<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(env('APP_NAME')); ?></title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
    <link class="js-stylesheet" href="<?php echo e(asset('assets/css/light.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">

    <?php if(Request::is('vehicles/upload/*') ||
            Request::is('headers') ||
            Request::is('runlist/upload') ||
            Request::is('vinocr/form') ||
            Request::is('inventory/copart') ||
            Request::is('buy/iaai')): ?>
        <link class="js-stylesheet2" href="<?php echo e(asset('assets/css/dropify.min.css')); ?>" rel="stylesheet">
    <?php endif; ?>
    <?php echo $__env->yieldContent('styles'); ?>


</head>

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-behavior="sticky">


    <div class="wrapper">

        <?php echo $__env->make('includes.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main">
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="content">
                <div class="container-fluid p-0">

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>

            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>


    <script src="<?php echo e(asset('/assets/js/app.js')); ?>"></script>

    

    <script>
        $(".select2").each(function() {
            $(this).select2();
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.2/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('assets/js/alerts.js')); ?>"></script>


    <?php echo $__env->yieldContent('alert'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

    <?php if(Request::is('vehicles/upload/*') ||
            Request::is('headers') ||
            Request::is('runlist/upload') ||
            Request::is('vinocr/form') ||
            Request::is('inventory/copart') ||
            Request::is('buy/iaai')): ?>
        <script src="<?php echo e(asset('assets/js/dropify.min.js')); ?>"></script>

        <script>
            $(document).ready(function() {
                $('input[type="file"]').addClass('dropify');
                $('.dropify').dropify();
            });
        </script>
    <?php endif; ?>

    <?php if(Request::has('type')): ?>
    <script>
        $('[data-target="#modal-vehicle-detail"]').css('color', '#495057');
    </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('/assets/js/vehicle-modal.js')); ?>"></script>


</body>

</html>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>