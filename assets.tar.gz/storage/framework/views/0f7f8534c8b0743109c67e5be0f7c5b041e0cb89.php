<?php
    $role = Auth()->user()->role;
?>

<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-left">














            </div>
            <div class="col-6 text-right">
                <p class="mb-0">
                    &copy; <?php echo e(date('Y')); ?> - <a href="<?php echo e(env('APP_URL')); ?>" class="text-muted"><?php echo e(env('APP_NAME')); ?></a>
                </p>
            </div>
        </div>
    </div>
</footer>

<?php echo $__env->make('pages.vehicle.modal.modal-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.vehicle.modal.modal-vehicle-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/d7gveui55lgt/public_html/resources/views/includes/footer.blade.php ENDPATH**/ ?>